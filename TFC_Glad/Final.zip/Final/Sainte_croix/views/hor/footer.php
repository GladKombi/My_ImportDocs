<link rel="stylesheet" href="css/style.css">
<footer class=" pt-5 text-white text-center text-small foter foot sign" >
      <!-- <button class="bi bi-moon-stars " id="theme-btn"  >  </button> -->
      <p class="mb-1">&copy; Lycee Butembo</p>
    
      
        <ul class="list-inline">
          <li class="nav-item  btn btn-warning"><a href="tel:+243993970466" class="nav-link px-2 text-dark bi bi-telephone-inbound"></a></li>
          <li class="nav-item btn btn-warning"><a href="mailto:samuelmurotso24@gmail.com" class="nav-link px-2 text-dark   bi bi-envelope"></a></li>
          <li class="nav-item btn btn-warning"><a href="https://www.facebook.com/profile.php?id=100063984192018" 
            class="nav-link px-2 text-dark  bi bi-facebook"></a></li>
          <li class="nav-item btn btn-warning"><a href="http://wa.me/+243975778865" 
            class="nav-link px-2 text-dark  bi bi-whatsapp"></a></li>
          
        </ul>
      
      &copy;Designed with love for you
      
    </footer>