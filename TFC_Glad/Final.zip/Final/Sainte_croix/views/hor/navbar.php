<!-- Fixed navbar -->

<!DOCTYPE html>
<html lang="en">
<head>
  <style>
.foot{
  background-color:rgb(119, 175, 236); 
}
  </style>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author"      content="Sergey Pozhilov (GetTemplate.com)">
	
	<title>Se connecter</title>

	<link rel="stylesheet" href="assetss/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assetss/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<nav class="navbar navbar-expand-lg navbar-dark foot d-flex"  aria-label="Tenth navbar example">
    <div class="container-fluid">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
        <ul class="navbar-nav ml-10 mr-10" style="margin:10px;">
          <li class="nav-item">
            <a class="nav-link active " aria-current="page" href="index.php">Accueil</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active " aria-current="page" href="about.php">A propos</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active " aria-current="page" href="contact.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active " aria-current="page" href="horaire.php">Horaire</a>
          </li>
         
        </ul>
      </div>
    </div>
  </nav>
	<!-- /.navbar -->