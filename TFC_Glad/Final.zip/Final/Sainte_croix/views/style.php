<link rel="stylesheet" href="../assets/css/bootstrap.css">
<link rel="stylesheet" href="../assets/vendors/chartjs/Chart.min.css">
<link rel="stylesheet" href="../assets/vendors/perfect-scrollbar/perfect-scrollbar.css">
<link rel="stylesheet" href="../assets/css/app.css">
<link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/x-icon">
<link rel="stylesheet" href="../assets/font/bootstrap-icons.css">
<link rel="stylesheet" href="../assets/vendors/simple-datatables/style.css">